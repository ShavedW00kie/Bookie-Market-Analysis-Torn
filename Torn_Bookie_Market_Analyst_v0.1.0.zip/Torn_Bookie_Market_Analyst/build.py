from pathlib import Path
import re, shutil
BASE=Path(__file__).resolve().parent
SRC=BASE/'project_sources' if (BASE/'project_sources').exists() else BASE.parent/'project_sources'
OUT=BASE.parent/'deliverables'
debug=(SRC/'03-userscript-debugger-module-1-.js').read_text()
debug=debug.replace('function initializeModularDebugger(scriptNamespace = "App") {\n    "use strict";', 'function initializeModularDebugger(scriptNamespace) {\n    "use strict";\n    if (scriptNamespace === undefined) scriptNamespace = "App";')
debug=debug.replace('Version: 1.0.2','Version: 1.0.3 (TBMA embedded adaptation)')
debug=debug.replace('const CLIPBOARD_MAX_CHARS = 10 * 1024 * 1024;', 'const CLIPBOARD_MAX_CHARS = 256 * 1024;')
debug=debug.replace('const BUFFER_REDUCTION_MARGIN = 900 * 1024;', 'const BUFFER_REDUCTION_MARGIN = 16 * 1024;')
debug=debug.replace('let cleanMessage = safeSerialize(message);','let cleanMessage = Core.redact(safeSerialize(message), [...sessionKeys.values()]);')
# Keep module code and public behavior; use on-demand observation instead of watching before first opening.
debug=debug.replace('        ensureObserver();\n\n        /*\n         * We intentionally', '        /* Observer is attached when the debugger is opened. */\n\n        /*\n         * We intentionally')
debug=debug.replace('approximately 9.1 million characters.', 'approximately 240 Ki characters in this embedded build.')
debug=debug.replace('Reserve approximately 900 KiB of headroom.', 'Reserve 16 Ki characters of headroom in this embedded build.')
donation=(SRC/'04-Donation_UI_Module.user-3-.js').read_text()
donation=donation[donation.index('/*'):]
donation=donation.replace('(function () {','function createSupportClass() {',1)
start=donation.index('    /* ============================================================\n     * MODULE STARTUP')
donation=donation[:start]+'    return SupportModule;\n}\nconst SupportModule = createSupportClass();\n'
donation=donation.replace('Version 1.4','Version 1.4.1 (TBMA embedded adaptation)',1)
donation=donation.replace('return document.body || null;', 'return this.config.mount && this.config.mount.isConnected ? this.config.mount : null;')
donation=donation.replace('            this.attachObserver();','            // Host lifecycle owns mounting; no second document observer.')
donation=donation.replace('                    position: fixed;\n                    bottom: 20px;\n                    right: 20px;\n                    z-index: 2147483640;', '                    position: static;')
donation=donation.replace('`tw-coffee-clip-${coffeeInstanceCount}`','`tbma-coffee-clip-${coffeeInstanceCount}`')
# CSS injection with a known id guarantees one style element through settings rebuilds.
a=donation.index('            if (typeof GM_addStyle === "function")')
b=donation.index('            this.injectStyleElement(styles);',a)
donation=donation[:a]+donation[b:]
# Scope animation/keyframe names and classes consistently to avoid other supplied module instances.
donation=donation.replace('tw-coffee-', 'tbma-coffee-')
donation=donation.replace('Append directly to body so React does not own\n                 * the donation UI\'s DOM subtree.', 'Append to the host settings mount. The host owns its lifecycle.')
meta='''// ==UserScript==
// @name         Torn Bookie Market Analyst
// @namespace    https://github.com/ShavedW00kie/
// @version      0.1.0
// @description  Verification release: read-only external odds, paper analysis, and sanitized DOM capture. Automatic Torn matching is not enabled.
// @author       ShavedW00kie (Torn: ThaWookie [2954173] )
// @license      BSD-3-Clause
// @match        https://www.torn.com/page.php*
// @run-at       document-end
// @noframes
// @grant        GM_info
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// @grant        GM.getValue
// @grant        GM.setValue
// @grant        GM.xmlHttpRequest
// @connect      api.the-odds-api.com
// @connect      api.oddspapi.io
// @connect      gamma-api.polymarket.com
// @connect      clob.polymarket.com
// ==/UserScript==

/* VERIFIED-CORE / DOM-EVIDENCE RELEASE, NOT A FINISHED AUTOMATIC BOOKIE ANALYST.
 * No native Torn DOM parser or guessed selectors. No bet placement.
 * See README and provider audit for blocked requirements.
 */
(function (nativeInfo) {
    "use strict";
    if (location.hostname !== "www.torn.com" || location.pathname !== "/page.php" ||
        new URLSearchParams(location.search).get("sid") !== "bookie") return;
'''
runtime=(BASE/'src/runtime.js').read_text().replace("const GM_info = typeof globalThis.GM_info !== 'undefined' ? globalThis.GM_info :", "const GM_info = nativeInfo ||")
# sessionKeys must exist before debugger initialization should it later add initialization logs.
runtime=runtime.replace('const MyDebug = initializeModularDebugger(GM_info.script.name);\n','').replace('const sessionKeys = new Map();','const sessionKeys = new Map();\nconst MyDebug = initializeModularDebugger(GM_info.script.name);')
text=meta+(BASE/'src/core.js').read_text()+'\n'+debug+'\n'+donation+'\n'+runtime+'\n'+(BASE/'src/providers.js').read_text()+'\n'+(BASE/'src/ui.js').read_text()+'''\n})(typeof GM_info !== "undefined" ? GM_info : null);\n'''
OUT.mkdir(exist_ok=True)
# Preserve requested name within ZIP; Markdown-safe linked files are staged separately.
name='Torn Bookie Market Analyst.user.js'
(BASE/name).write_text(text)
(OUT/'Torn_Bookie_Market_Analyst.user.js').write_text(text)
(OUT/'Torn_Bookie_Market_Analyst.user.js.txt').write_text(text)
(BASE/'src/embedded-debugger.js').write_text(debug)
(BASE/'src/embedded-donation.js').write_text(donation)
print(f'Built {len(text):,} characters, self-contained verification release')
