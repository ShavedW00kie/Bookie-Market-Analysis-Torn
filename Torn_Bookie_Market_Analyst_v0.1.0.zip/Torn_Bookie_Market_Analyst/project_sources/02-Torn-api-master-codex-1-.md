---
name: torn-api-master-codex
description: Complete codex reference for Torn API endpoints, parameters, schemas, limits, caching, error codes, acceptable usage, and compliance.
---

# Torn API Master Codex Skill

## Purpose
Provide a unified codex for Torn API usage in ai platforms and userscript development. Consolidates endpoint definitions, parameters, schemas, error codes, caching rules, acceptable usage, and ToS compliance into one reference.

## Instructions
1. Use this skill when building Torn.com userscripts or API integrations.  
2. Reference endpoint definitions and schemas directly.  
3. Respect rate limits (100 requests/minute).  
4. Handle errors fail‑closed.  
5. Follow acceptable usage and ToS guidelines.  
6. Keep API keys secure and confidential.  
7. Optimize requests to fetch only required data.

## Acceptable Usage & ToS
- **Never request Torn passwords.**  
- Only request API keys.  
- Keys and data must be kept confidential.  
- No deceptive usage or misuse.  
- Misuse → permanent bans.  
- Scripts must be optimized to retrieve minimal data.  
- ToS must clearly state data storage, sharing, purpose, and key handling.

## API v2 Selections

The following selections are supported in **API v2** (or both v1 and v2). Use them in the `selections` parameter when querying endpoints.

### User
- hof  
- competition  
- faction  
- forumposts  
- forumthreads  
- job  
- properties  
- basic  
- bazaar  
- bounties  
- criminalrecord  
- discord  
- display  
- icons  
- lookup  
- medals  
- personalstats  
- profile  
- property  
- timestamp  
- calendar  
- enlistedcars  
- forumfeed  
- forumfriends  
- forumsubscribedthreads  
- itemmods  
- organizedcrime / organizedcrimes  
- races / racingrecords  
- virus  
- ammo  
- bars  
- cooldowns  
- crimes  
- education  
- equipment  
- gym  
- honors  
- inventory  
- jobpoints  
- jobranks  
- merits  
- missions  
- notifications  
- perks  
- refills  
- revives / revivesfull  
- skills  
- travel  
- weaponexp  
- workstats  

### Faction
- chainreport  
- members  
- rackets  
- raids  
- rankedwarreport  
- search  
- territoryownership  
- territorywarreport  
- territorywars  
- warfare  
- wars  
- basic  
- chain / chains  
- hof  
- lookup  
- raidreport  
- rankedwars  
- territory  
- timestamp  
- crime  
- news (armorynews, crimenews, mainnews, membershipnews, territorynews)  
- applications  
- armor  
- boosters  
- caches  
- crimeexp  
- crimes  
- drugs  
- medical  
- positions  
- revives / revivesfull  
- stats  
- temporary  
- upgrades  
- utilities  
- weapons  
- balance  
- attacknews, currency, donations, fundsnews  
- attacks / attacksfull  
- cesium  
- contributors  
- reports  

### Company
- search  
- snapshot  
- companies  
- employees  
- lookup  
- profile  
- timestamp  
- detailed  
- applications  
- news  
- stock  

### Property
- lookup  
- property  
- timestamp  

### Market
- auctionhouse / auctionhouselisting  
- itemmarket  
- properties  
- rentals  
- bazaar  
- lookup  
- pointsmarket  
- timestamp  

### Torn
- attacklog  
- bounties  
- calendar  
- crimes  
- hof  
- itemammo  
- itemmods  
- merits  
- organizedcrimes / subcrimes  
- chainreport  
- dirtybombs  
- elimination / eliminationteam  
- rackets  
- raidreport  
- rankedwarreport / rankedwars  
- territorynames / territorywarreport / territorywars  
- bank  
- cards  
- cityshops  
- companies  
- competition  
- education  
- eliminationattacks  
- factionhof / factiontree  
- gyms  
- honors  
- itemdetails / items / itemstats  
- logcategories / logtypes  
- lookup  
- medals  
- organisedcrimes  
- pawnshop  
- pokertables  
- properties  
- raids  
- rockpaperscissors  
- searchforcash  
- shoplifting  
- stats  
- stocks  
- territory  
- timestamp  

### Racing
- cars  
- carupgrades  
- race  
- races  
- records  
- tracks  
- lookup  
- timestamp  

### Forum
- categories  
- posts  
- thread  
- threads  
- lookup  
- timestamp  

### Key
- log  
- info


## Parameters
- **`selections`** → specify data sets (comma-separated)  
- **`id`** → target entity ID  
- **`timestamp`** → bypass service cache

## Access Levels
- **Public**  
- **Minimal**  
- **Limited**  
- **Full**

## Error Codes
- **0** → Unknown error  
- **1** → Key is empty  
- **2** → Incorrect key (**permanent**)  
- **3** → Wrong type  
- **4** → Wrong fields  
- **5** → Too many requests (rate limit)  
- **6** → Incorrect ID  
- **7** → Incorrect ID-entity relation  
- **8** → IP block  
- **9** → API disabled  
- **10** → Key owner in federal jail (**permanent**)  
- **11** → Key change error  
- **12** → Key read error  
- **13** → Key disabled due to inactivity (**permanent**)  
- **14** → Daily read limit reached  
- **15** → Temporary error  
- **16** → Access level too low  
- **17** → Backend error  
- **18** → API key paused  
- **19** → Must migrate to crimes 2.0  
- **20** → Race not finished  
- **21** → Incorrect category  
- **22** → Selection only in API v1  
- **23** → Selection only in API v2  
- **24** → Closed temporarily  
- **25–30** → Extended errors (invalid stat, log ID, deprecated selections)

## Caching
- **Service Cache** → up to 30s, bypass with `timestamp`.  
- **Global Cache** → server-side, cannot be bypassed.  
  - **Commonly cached endpoints**:  
    - `market -> itemmarket`  
    - `market -> properties`  
    - `market -> rentals`  
    - `company -> companies`  
    - `user -> bazaar`  
    - `torn -> bounties`  
    - `user -> bounties`

## Rate Limits
- **100 requests/minute** across all keys.  
- Invalid key spam or abusive patterns may trigger temporary IP bans.

## Deprecation Notices
- `company -> companies` capped at **100 rows** (effective June 1, 2026).  
- `faction -> crimes` CPR empty slots → **0** (effective June 1, 2026).  
- `position_id` & `position_number` **deprecated** → replaced by `position_info`.  
- `id` deprecated in `TornOrganizedCrimeSlot` → replaced by `position_info`.

## Best Practices (summary)
- Request only the `selections` you need.  
- Respect rate limits and implement client-side throttling.  
- Use `timestamp` sparingly to bypass short service cache when necessary.  
- Store API keys securely and never embed them in public code.  
- Monitor key usage via `key -> log` and rotate keys if compromised.  
- Fail closed on unexpected errors; surface clear messages to users.

---
