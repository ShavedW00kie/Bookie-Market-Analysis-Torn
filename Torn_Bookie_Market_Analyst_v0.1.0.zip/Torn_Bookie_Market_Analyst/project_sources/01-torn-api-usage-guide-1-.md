---
name: torn-api-usage-guide
description: Practical usage guide for Torn API requests and responses.
---

# Torn API Quick Usage Guide

## Purpose
Provide developers with practical examples of how to query Torn API endpoints, handle parameters, and interpret responses.

## Authentication
- All requests require an API key.  
- Keys must be kept confidential and never shared.  
- Example request:  
  `https://api.torn.com/user/?selections=profile&key=YOUR_API_KEY`

## Example Requests

### User Profile
```http
GET https://api.torn.com/user/?selections=profile&key=YOUR_API_KEY
```
**Response (JSON):**
```json
{
  "player_id": 12345,
  "name": "ExampleUser",
  "level": 50,
  "status": "Okay"
}
```

### Faction Members
```http
GET https://api.torn.com/faction/?selections=members&key=YOUR_API_KEY
```
**Response (JSON):**
```json
{
  "members": {
    "12345": { "name": "Leader", "level": 60 },
    "67890": { "name": "Member", "level": 40 }
  }
}
```

### Item Market
```http
GET https://api.torn.com/market/?selections=itemmarket&key=YOUR_API_KEY
```
**Response (JSON):**
```json
{
  "items": [
    { "item_id": 1, "name": "Plushie", "price": 5000 },
    { "item_id": 2, "name": "Flower", "price": 3000 }
  ]
}
```

### Combining selections
You can request multiple selections in one call by comma‑separating them in the `selections` parameter. Order does not change the response semantics, but long lists should be URL‑encoded when embedded in other contexts.

**Example**
```http
GET https://api.torn.com/user/?selections=profile,inventory,merits&key=YOUR_API_KEY
```

**Notes**
- **URL encoding**: If you build the URL programmatically, ensure the `selections` value is URL‑encoded.  
- **Limits and performance**: Request only the selections you need; combining many heavy selections increases response size and may hit service cache or rate limits.  
- **Cache behavior**: Use `timestamp` to bypass the short service cache for freshness; see Parameters for details.  
- **Version differences**: Some selections are v1 only or v2 only. Confirm the selection is supported in API v2 before relying on it in new code.


## Parameters
- **`selections`**: Comma-separated list of data sets to retrieve. Multiple selections may be requested in one call (e.g., `profile,inventory,merits`).
- **`id`**: Target entity ID (user, faction, company).  
- **`timestamp`**: Optional; bypasses service cache for short-lived freshness.


## Error Handling
- Always check for an `error` object in responses.  
- Example:
```json
{ "error": { "code": 5, "error": "Too many requests" } }
```
- **Pattern**: if `error.code` is present, handle according to codex rules (retry/backoff for rate limits, fail‑closed for permanent key errors).

## Best Practices
- Limit requests to only required `selections`.  
- Respect rate limits (100 requests/minute).  
- Cache responses client-side where appropriate to reduce calls.  
- Use `timestamp` only when you must bypass the short service cache.  
- Monitor API key usage via `key -> log` and rotate keys if suspicious activity appears.  
- Provide clear user-facing error messages and guidance when API errors occur.

---
```
