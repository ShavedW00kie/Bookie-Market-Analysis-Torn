'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const src=n=>fs.readFileSync(path.join(__dirname,'../src',n),'utf8');
function setup(response,options={}) {
 const db=new Map(),logs=[],calls=[];let readsFail=false;let count=0;
 const context=vm.createContext({Date,URL,URLSearchParams,Headers,AbortController,setTimeout:fn=>{fn();return 1;},clearTimeout:()=>{},
  nativeInfo:null,GM_getValue:async(k,d)=>{if(readsFail)throw Error('Storage failed');return db.has(k)?structuredClone(db.get(k)):d;},GM_setValue:async(k,v)=>db.set(k,structuredClone(v)),
  location:{hostname:'www.torn.com',pathname:'/page.php',search:'?sid=bookie'},document:{hidden:false},
  navigator:{locks:{request:async(name,fn)=>fn()}},
  initializeModularDebugger:()=>({log:(...x)=>logs.push(x)}),
  GM_xmlhttpRequest:request=>{calls.push(request);count++;const r=typeof response==='function'?response(count,request):response;queueMicrotask(()=>request.onload({...r,finalUrl:request.url,responseText:JSON.stringify(r.data),responseHeaders:r.headers||''}));},
 });
 vm.runInContext(src('core.js')+'\n'+src('runtime.js')+`\nsettings.toaEnabled=true; settings.papiEnabled=true; settings.polyEnabled=true;
 globalThis.T={api,Storage,networkState,allowedURL,set:(k,v)=>settings[k]=v,advance:()=>routeGeneration++,setRaw:f=>rawGET=f};`,context);
 return {t:context.T,context,db,logs,calls,failReads:()=>{readsFail=true;}};
}
const good={status:200,data:[]};
test('no secret storage fallback to localStorage',async()=>{const x=setup(good);await x.t.Storage.saveKey('toa','privateKEY123',true);assert.equal(await x.t.Storage.key('toa'),'privateKEY123');assert.equal(x.db.get('tbma.v1.secret.toa'),'privateKEY123');await x.t.Storage.saveKey('toa','temporary456',false);assert.equal(x.db.get('tbma.v1.secret.toa'),'');});
test('missing credentials produce zero requests',async()=>{const x=setup(good);await assert.rejects(x.t.api('toa','/v4/sports',{},0),/API key/);assert.equal(x.calls.length,0);});
test('in-flight deduplication and empty negative cache',async()=>{const x=setup(good);await x.t.Storage.saveKey('toa','secret',true);const [a,b]=await Promise.all([x.t.api('toa','/v4/sports',{},0),x.t.api('toa','/v4/sports',{},0)]);assert.equal(x.calls.length,1);await x.t.api('toa','/v4/sports',{},0);assert.equal(x.calls.length,1);assert.equal(a.length,0);assert.equal(b.length,0);});
test('secret-bearing URL never reaches logs',async()=>{const x=setup(good);await x.t.Storage.saveKey('toa','privateKEY123',true);await x.t.api('toa','/v4/sports',{},0);assert.ok(x.calls[0].url.includes('privateKEY123'));assert.ok(!JSON.stringify(x.logs).includes('privateKEY123'));});
test('budget reservation happens before request and stops at cap',async()=>{const x=setup(good);x.t.set('toaBudget',1);await x.t.Storage.saveKey('toa','secret',false);await x.t.api('toa','/v4/sports/test/events/a/odds',{},1,0);await assert.rejects(x.t.api('toa','/v4/sports/test/events/b/odds',{},1,0),/budget exhausted/);assert.equal(x.calls.length,1);});
test('quota storage failure is fail-closed',async()=>{const x=setup(good);await x.t.Storage.saveKey('toa','secret',false);x.failReads();await assert.rejects(x.t.api('toa','/v4/sports/test/events/a/odds',{},1,0));assert.equal(x.calls.length,0);});
test('429 honors Retry-After, no immediate retry',async()=>{const x=setup({status:429,data:{},headers:'Retry-After: 60'});await x.t.Storage.saveKey('toa','secret',false);await assert.rejects(x.t.api('toa','/v4/sports',{},0,0),/Rate limit/);await assert.rejects(x.t.api('toa','/v4/sports',{},0,0),/cooldown/);assert.equal(x.calls.length,1);});
test('server remaining zero prevents billable request',async()=>{const x=setup({status:200,data:[],headers:'x-requests-remaining: 0'});await x.t.Storage.saveKey('toa','secret',false);await x.t.api('toa','/v4/sports',{},0,0);await assert.rejects(x.t.api('toa','/v4/sports/test/events/a/odds',{},1,0),/remaining quota/);});
test('bounded server retries reserve credits on every attempt',async()=>{const x=setup(n=>({status:n<3?503:200,data:[]}));await x.t.Storage.saveKey('toa','secret',false);await x.t.api('toa','/v4/sports/test/events/a/odds',{},1,0);assert.equal(x.calls.length,3);assert.equal(x.db.get('tbma.v1.budget.toa').used,3);});
test('403 pauses provider, does not rotate hosts',async()=>{const x=setup({status:403,data:{}});await x.t.Storage.saveKey('toa','secret',false);await assert.rejects(x.t.api('toa','/v4/sports',{},0,0),/permission/);await assert.rejects(x.t.api('toa','/v4/sports',{},0,0),/cooldown/);assert.equal(x.calls.length,1);});
test('unsupported provider/path cannot send requests',async()=>{const x=setup(good);await assert.rejects(x.t.api('kalshi','/markets'),/not implemented/);assert.throws(()=>x.t.allowedURL('https://api.the-odds-api.com/v4/trade'));assert.throws(()=>x.t.allowedURL('https://evil.example/'));assert.equal(x.calls.length,0);});
test('hidden page never sends',async()=>{const x=setup(good);x.context.document.hidden=true;await assert.rejects(x.t.api('poly','/markets/123'),/hidden/);assert.equal(x.calls.length,0);});
test('request response discarded after route generation changes',async()=>{const x=setup(good);x.t.setRaw(async()=>{x.t.advance();return {status:200,text:'[]',headers:{}};});await assert.rejects(x.t.api('poly','/markets/123'),/response discarded/);});
test('missing cross-tab lock disables reads explicitly',async()=>{const x=setup(good);x.context.navigator.locks=null;await assert.rejects(x.t.api('poly','/markets/123'),/lock unavailable/);assert.equal(x.calls.length,0);});
test('OddsPapi account response drops API key and personal fields before caching',async()=>{const x=setup({status:200,data:{api_key:'DONOTSTORE',subscriptions:[{is_active:true,request_count:5,request_limit:250}]}});await x.t.Storage.saveKey('papi','real-key',false);const r=await x.t.api('papi','/v4/account',{},0,0);assert.equal(r.remaining,245);assert.ok(!JSON.stringify([...x.db]).includes('DONOTSTORE'));assert.ok(!JSON.stringify(x.logs).includes('DONOTSTORE'));});
test('session-only keys when GM storage unavailable',async()=>{const stored=[];const context=vm.createContext({Date,URL,URLSearchParams,Headers,AbortController,setTimeout,clearTimeout,nativeInfo:null,
 localStorage:{getItem:()=>null,setItem:(...x)=>stored.push(x)},initializeModularDebugger:()=>({log:()=>{}})});
 vm.runInContext(src('core.js')+'\n'+src('runtime.js')+'\nglobalThis.S=Storage;',context);await context.S.saveKey('toa','sessionKey',false);assert.equal(await context.S.key('toa'),'sessionKey');assert.equal(stored.length,0);await assert.rejects(context.S.saveKey('toa','bad',true),/unavailable/);});
