/* Runtime services. Fail closed on storage, quota, or transport uncertainty. */
const VERSION = '0.1.0';
const APP = 'Torn Bookie Market Analyst';
const GM_info = typeof globalThis.GM_info !== 'undefined' ? globalThis.GM_info :
    (typeof GM !== 'undefined' && GM.info ? GM.info : {script:{name:APP,version:VERSION}});
const MyDebug = initializeModularDebugger(GM_info.script.name);
const PREFIX = 'tbma.v1.';
const sessionKeys = new Map();
const gmRead = typeof GM_getValue === 'function' ? GM_getValue :
    (typeof GM !== 'undefined' && typeof GM.getValue === 'function' ? GM.getValue.bind(GM) : null);
const gmWrite = typeof GM_setValue === 'function' ? GM_setValue :
    (typeof GM !== 'undefined' && typeof GM.setValue === 'function' ? GM.setValue.bind(GM) : null);
const isolatedStorage = Boolean(gmRead && gmWrite);
const Storage = {
    async read(key, fallback) {
        try {
            if (isolatedStorage) return await gmRead(PREFIX+key,fallback);
            const raw=localStorage.getItem(PREFIX+key);
            return raw===null?fallback:JSON.parse(raw);
        } catch (_) { return fallback; }
    },
    async required(key, fallback) {
        if (isolatedStorage) return await gmRead(PREFIX+key,fallback);
        const raw=localStorage.getItem(PREFIX+key);
        return raw===null?fallback:JSON.parse(raw);
    },
    async write(key,value) {
        if (isolatedStorage) await gmWrite(PREFIX+key,value);
        else localStorage.setItem(PREFIX+key,JSON.stringify(value));
    },
    async key(provider) {
        if (sessionKeys.has(provider)) return sessionKeys.get(provider);
        if (!isolatedStorage) return '';
        try { const key=await gmRead(PREFIX+'secret.'+provider,''); if(typeof key==='string') {sessionKeys.set(provider,key);return key;} } catch (_) {}
        return '';
    },
    async saveKey(provider,value,persist) {
        if (value && (value.length>256 || /\s/.test(value))) throw new Error('Invalid credential: no whitespace; maximum 256 characters');
        if (persist && !isolatedStorage) throw new Error('Isolated userscript storage unavailable; use session-only entry');
        if (isolatedStorage) await gmWrite(PREFIX+'secret.'+provider,persist?value:'');
        sessionKeys.set(provider,value);
    }
};
function log(operation, detail, level='INFO') {
    MyDebug.log(Core.redact({operation,detail},[...sessionKeys.values()]),level);
}
const DEFAULTS={collapsed:false,stake:10000,maxStake:100000,bankroll:0,dailyStake:500000,maxExposure:500000,lossLimit:0,profitTarget:0,minEdge:0.03,minSources:2,maxAge:300,
    toaEnabled:false,papiEnabled:false,polyEnabled:false,toaBudget:100,papiBudget:50,polyBudget:1000};
let settings={...DEFAULTS};
const PROVIDERS={
    toa:{name:'The Odds API',host:'api.the-odds-api.com',limit:500,gap:1100},
    papi:{name:'OddsPapi',host:'api.oddspapi.io',limit:250,gap:2100},
    poly:{name:'Polymarket',host:'gamma-api.polymarket.com',limit:1000,gap:1100}
};
const networkState=new Map();
const inflight=new Map();
let networkTail=Promise.resolve();
let routeGeneration=0;
const isBookie=()=>location.hostname==='www.torn.com' && location.pathname==='/page.php' && new URLSearchParams(location.search).get('sid')==='bookie';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms)); // Network scheduling only; never DOM polling.
function headersMap(raw) {
    if (raw instanceof Headers) return Object.fromEntries([...raw.entries()]);
    const out={}; for(const line of String(raw||'').split(/\r?\n/)) {const i=line.indexOf(':');if(i>0)out[line.slice(0,i).trim().toLowerCase()]=line.slice(i+1).trim();} return out;
}
function allowedURL(url) {
    const u=new URL(url);
    if(u.protocol!=='https:' || u.username || u.password || u.hash) throw new Error('Invalid API destination');
    const rules={
        'api.the-odds-api.com':/^\/v4\/sports\/?$|^\/v4\/sports\/[a-z0-9_]+\/events(?:\/[a-zA-Z0-9_-]+\/odds)?\/?$/,
        'api.oddspapi.io':/^\/v4\/(account|fixtures|markets|odds)$/,
        'gamma-api.polymarket.com':/^\/markets\/\d+$/,
        'clob.polymarket.com':/^\/book$/
    };
    if(!rules[u.hostname]?.test(u.pathname)) throw new Error('API path is not allowlisted');
    return u;
}
async function rawGET(url) {
    allowedURL(url);
    const gm=typeof GM_xmlhttpRequest==='function'?GM_xmlhttpRequest:
        (typeof GM!=='undefined' && typeof GM.xmlHttpRequest==='function'?GM.xmlHttpRequest.bind(GM):null);
    if(gm) return new Promise((resolve,reject)=>{
        let done=false;
        const ok=r=>{if(done)return;done=true;try{
            if(r.finalUrl && new URL(r.finalUrl).origin!==new URL(url).origin) throw new Error('Cross-origin redirect rejected');
            resolve({status:r.status,headers:headersMap(r.responseHeaders),text:String(r.responseText||'')});
        }catch(_){reject(new Error('Unexpected API redirect'));}};
        const bad=message=>{if(!done){done=true;reject(new Error(message));}};
        try {
            const handle=gm({method:'GET',url,anonymous:true,timeout:15000,redirect:'error',headers:{Accept:'application/json'},
                onload:ok,onerror:()=>bad('Network request failed'),ontimeout:()=>bad('API timeout'),onabort:()=>bad('Request aborted')});
            if(handle && typeof handle.then==='function') handle.then(ok,()=>bad('Network request failed'));
        }catch(_){bad('GM request transport unavailable');}
    });
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),15000);
    try {
        const r=await fetch(url,{method:'GET',mode:'cors',credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',headers:{Accept:'application/json'},signal:controller.signal});
        return {status:r.status,headers:headersMap(r.headers),text:await r.text()};
    } catch (_) {throw new Error('Cross-origin fetch failed or CORS is unavailable. Use a supported userscript request transport.');}
    finally {clearTimeout(timer);}
}
async function serializedNetwork(fn) {
    const next=networkTail.then(async()=>{
        if(!navigator.locks?.request) throw new Error('Cross-tab request lock unavailable in this environment; API reads disabled to protect quotas');
        return navigator.locks.request(PREFIX+'network',fn);
    });
    networkTail=next.catch(()=>{}); return next;
}
async function api(provider,path,params={},cost=1,ttl=60000) {
    if(!PROVIDERS[provider]) throw new Error('Provider not implemented');
    if(!settings[provider+'Enabled']) throw new Error('Enable this provider in settings first');
    const generation=routeGeneration;
    const cacheName=provider+':'+path+':'+JSON.stringify(params);
    if(inflight.has(cacheName)) return inflight.get(cacheName);
    const work=serializedNetwork(async()=>{
        if(!isBookie() || generation!==routeGeneration || document.hidden) throw new Error('Page changed or hidden; request cancelled');
        const conf=PROVIDERS[provider];
        const cache=ttl?await Storage.read('cache.'+cacheName,null):null;
        if(cache && cache.expires>Date.now()) return cache.data;
        let key='';
        if(provider!=='poly') { key=await Storage.key(provider); if(!key)throw new Error('Enter an API key in settings'); }
        const url=new URL(path,'https://'+(path==='/book'?'clob.polymarket.com':conf.host));
        for(const [k,v] of Object.entries(params)) url.searchParams.set(k,String(v));
        if(key)url.searchParams.set('apiKey',key);
        allowedURL(url.href);
        for(let attempt=0;attempt<3;attempt++) {
            let budget=await Storage.required('budget.'+provider,{});
            if (!budget || typeof budget!=='object') throw new Error('Corrupt quota state; requests disabled');
            const month=new Date().toISOString().slice(0,7);
            if(budget.month!==month)budget={month,used:0,nextAt:0,blockedUntil:0};
            if (!Number.isFinite(budget.used) || budget.used<0) throw new Error('Corrupt quota counter; requests disabled');
            if(budget.blockedUntil>Date.now()) throw new Error('Provider in cooldown; try after '+new Date(budget.blockedUntil).toISOString());
            if(cost && budget.used+cost>Math.min(settings[provider+'Budget'],conf.limit)) throw new Error('Local monthly request budget exhausted');
            if(cost && budget.remaining===0) throw new Error('Provider reports no remaining quota');
            const delay=Math.max(0,(budget.nextAt||0)-Date.now());
            if(delay>30000)throw new Error('Provider cooldown active');
            if(delay)await sleep(delay);
            if(generation!==routeGeneration || document.hidden || !isBookie())throw new Error('Page changed; request cancelled');
            budget.used+=cost; budget.nextAt=Date.now()+conf.gap;
            await Storage.write('budget.'+provider,budget); // Reserve before send, including errors/retries.
            networkState.set(provider,{status:'Requesting',used:budget.used});
            let r;
            try {r=await rawGET(url.href);} catch(e) {networkState.set(provider,{status:e.message,used:budget.used});throw e;}
            if(r.headers['x-requests-remaining']!==undefined && /^\d+$/.test(r.headers['x-requests-remaining']))budget.remaining=Number(r.headers['x-requests-remaining']);
            if(r.status===429) {
                const h=r.headers['retry-after'];
                const seconds=h && /^\d+(?:\.\d+)?$/.test(h)?Number(h):null;
                const until=seconds!==null?Date.now()+seconds*1000:Date.parse(h||'');
                // Do not repeatedly probe monthly exhaustion. Even an unspecified 429 pauses ten minutes.
                budget.blockedUntil=Number.isFinite(until)?Math.max(Date.now()+2000,until):Date.now()+600000;
                await Storage.write('budget.'+provider,budget);
                throw new Error('Rate limit or quota reached; automatic retries paused');
            }
            await Storage.write('budget.'+provider,budget);
            if(r.status===401 || r.status===403) {
                budget.blockedUntil=Date.now()+3600000; await Storage.write('budget.'+provider,budget);
                throw new Error('Authentication or permission rejected; update credentials or review access');
            }
            if(r.status>=500 && attempt<2) {await sleep(1000*2**attempt+Math.floor(Math.random()*250));continue;}
            if(r.status<200 || r.status>=300)throw new Error('API returned HTTP '+r.status);
            if(generation!==routeGeneration || !isBookie() || document.hidden)throw new Error('Page changed; response discarded');
            if(r.text.length>5*1024*1024)throw new Error('API response too large');
            let data; try{data=JSON.parse(r.text);}catch(_){throw new Error('Malformed API JSON');}
            if(data && typeof data==='object' && data.error) throw new Error('API reported an error');
            if(provider==='papi' && path==='/v4/account') {
                const active=Array.isArray(data.subscriptions)?data.subscriptions.find(s=>s.is_active===true):null;
                if(!active)throw new Error('No active OddsPapi subscription in response');
                const count=Core.number(active.request_count),limit=Core.number(active.request_limit);
                data={requestCount:count,requestLimit:limit,remaining:Math.max(0,limit-count)};
                budget.remaining=data.remaining; await Storage.write('budget.'+provider,budget);
            }
            // Never cache account responses or any raw credential-bearing result.
            if(ttl && path!=='/v4/account') {
                const index=await Storage.read('cacheIndex',[]);
                const entries=(Array.isArray(index)?index:[]).filter(x=>x!==cacheName);
                entries.push(cacheName);
                while(entries.length>40) await Storage.write('cache.'+entries.shift(),null);
                await Storage.write('cache.'+cacheName,{expires:Date.now()+ttl,data});
                await Storage.write('cacheIndex',entries);
            }
            networkState.set(provider,{status:'OK',used:budget.used,remaining:budget.remaining,at:Date.now()});
            log('api',{provider,path,status:r.status,cost});
            return data;
        }
        throw new Error('Retry limit reached');
    }).catch(e=>{networkState.set(provider,{status:e.message});log('api-failure',{provider,message:e.message},'WARN');throw e;}).finally(()=>inflight.delete(cacheName));
    inflight.set(cacheName,work);return work;
}
