/* Verification-release interface. No selectors for unobserved Torn event markup. */
const CATEGORIES=['American Football','Australian Football','Badminton','Baseball','Basketball','Boxing','Counter-Strike','Dota 2','Football','Formula 1','Handball','Hockey','Horse Racing','League of Legends','MMA UFC','Overwatch','Rugby','Rugby League','Snooker','StarCraft 2','Tennis','Volleyball'];
let root,content,statusLine,sourceArea,settingsArea,ledgerArea,support,lifeObserver;
let journal=[],currentReference=null,cancelPick=null,freshnessTimer=null;
const listeners=new AbortController();
const el=(tag,text='',className='')=>{const n=document.createElement(tag);n.textContent=text;if(className)n.className=className;return n;};
const percent=p=>(p*100).toFixed(1)+'%';
const money=n=>'$'+n.toLocaleString('en-US',{maximumFractionDigits:2});
function button(label,fn) {
    const b=el('button',label);b.type='button';b.addEventListener('click',async function(){
        if(b.disabled)return;b.disabled=true;
        try{await fn.call(this);}catch(e){showError(e);}finally{b.disabled=false;renderHealth();}
    });return b;
}
function showError(error){if(statusLine)statusLine.textContent='⚠ '+Core.redact(error?.message||'Operation failed',[...sessionKeys.values()]);log('ui-error',error?.message||'Operation failed','WARN');}
function labelInput(parent,label,type='text',value='') {
    const wrap=el('label','', 'tbma-field'),text=el('span',label),input=el('input');input.type=type;input.value=String(value);wrap.append(text,input);parent.append(wrap);return input;
}
function selectInput(parent,label,choices) {
    const wrap=el('label','', 'tbma-field'),select=el('select');wrap.append(el('span',label),select);parent.append(wrap);
    for(const [value,text]of choices) {const o=el('option',text);o.value=value;select.append(o);}return select;
}
function detail(parent,title){const d=el('details'),s=el('summary',title);d.append(s);parent.append(d);return d;}
function table(parent,headers,rows) {
    const wrap=el('div','', 'tbma-scroll'),t=el('table'),head=el('thead'),tr=el('tr');headers.forEach(h=>tr.append(el('th',h)));head.append(tr);t.append(head);
    const body=el('tbody');for(const row of rows){const r=el('tr');for(const cell of row){const td=el('td');if(cell instanceof Node)td.append(cell);else td.textContent=String(cell??'Unknown');r.append(td);}body.append(r);}t.append(body);wrap.append(t);parent.append(wrap);
}
function safeLink(parent,label,url){const a=el('a',label);a.href=url;a.target='_blank';a.rel='noopener noreferrer';parent.append(a);return a;}
async function download(name,text,type='application/json') {
    const url=URL.createObjectURL(new Blob([text],{type}));const a=el('a');a.download=name;a.href=url;root.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000); // Download URL lifetime, not DOM discovery.
}
function renderHealth(){if(!root)return;const area=root.querySelector('[data-tbma-health]');if(!area)return;area.replaceChildren();
    for(const [id,p]of Object.entries(PROVIDERS)){const h=networkState.get(id);area.append(el('span',`${p.name}: ${settings[id+'Enabled']?(h?.status||'ready, not tested'):'disabled'}${h?.used!==undefined?' · local credits '+h.used:''}${h?.remaining!==undefined?' · server remaining '+h.remaining:''}`));}}
async function changeKey(id,value,persist){await Storage.saveKey(id,value,persist);const b=await Storage.read('budget.'+id,{});b.blockedUntil=0;delete b.remaining;await Storage.write('budget.'+id,b);networkState.delete(id);statusLine.textContent=value?(persist?'Key saved in userscript storage.':'Key kept for this page session only.'):'Key deleted.';}
async function buildSettings() {
    settingsArea.replaceChildren(el('h3','Settings'));
    settingsArea.append(el('p',isolatedStorage?'Keys can be saved in userscript-manager storage. They are not encrypted by this script.':'No isolated GM storage: credentials are session-only. Other settings use local storage.'));
    const grid=el('div','','tbma-grid');settingsArea.append(grid);
    const fields={};
    for(const [k,label]of [['stake','Default hypothetical stake'],['maxStake','Advisory stake cap'],['bankroll','Optional bankroll (0 = unset)'],['dailyStake','Daily stake advisory'],['maxExposure','Pending exposure advisory'],['lossLimit','Daily loss advisory (0 = off)'],['profitTarget','Aspirational daily profit (0 = off)'],['minSources','Minimum sources for future value signals'],['maxAge','Maximum source age (seconds)'],['toaBudget','The Odds API monthly credit budget (max 500)'],['papiBudget','OddsPapi monthly request budget (max 250)'],['polyBudget','Polymarket local monthly request budget (max 1000)']])fields[k]=labelInput(grid,label,'number',settings[k]);
    fields.minEdge=labelInput(grid,'Minimum probability edge (percentage points)','number',settings.minEdge*100);fields.minEdge.step='0.1';
    settingsArea.append(button('Save settings',async()=>{
        const next={...settings};for(const [k,input]of Object.entries(fields)){const n=Core.number(input.value,k);if(n<0 || n>1e9)throw new Error('Setting out of range');next[k]=n;}
        next.minEdge/=100;
        if(next.minEdge>1 || next.maxAge<30 || next.maxAge>3600 || !Number.isInteger(next.minSources)||next.minSources<1||next.minSources>20)throw new Error('Invalid quality threshold');
        for(const p of ['toa','papi','poly'])if(!Number.isInteger(next[p+'Budget']) || next[p+'Budget']>PROVIDERS[p].limit)throw new Error('Budget exceeds free/local cap');
        await Storage.write('settings',next);settings=next;statusLine.textContent='Settings saved. Limits are advisory and apply only to locally recorded paper bets.';
    }));
    settingsArea.append(el('p','All amounts are Torn dollars. Daily summaries use UTC. Profit targets never change stakes. This release does not know your actual bets or full account exposure. API refresh is manual and cache-aware. Local monthly budgets use calendar months; provider billing quotas may reset on different dates.'));
    for(const [id,p]of Object.entries(PROVIDERS)) {
        const box=detail(settingsArea,p.name);
        const enabled=labelInput(box,'Enable read-only requests','checkbox');enabled.checked=settings[id+'Enabled'];
        enabled.addEventListener('change',()=>void(async()=>{try{const next={...settings,[id+'Enabled']:enabled.checked};await Storage.write('settings',next);settings=next;renderHealth();}catch(e){showError(e);}})());
        if(id!=='poly') {
            const input=labelInput(box,'API key','password','');input.autocomplete='off';input.spellcheck=false;
            const persist=labelInput(box,'Remember key in isolated userscript storage','checkbox');persist.checked=isolatedStorage;persist.disabled=!isolatedStorage;
            box.append(button('Show / hide',()=>{input.type=input.type==='password'?'text':'password';}),button('Save key',async()=>{await changeKey(id,input.value.trim(),persist.checked);input.value='';}),button('Delete saved key',async()=>{await changeKey(id,'',false);input.value='';}));
            box.append(button('Test saved key',async()=>{
                if(id==='toa'){const s=await Providers.sports();statusLine.textContent='Key test passed; '+s.length+' active sports/competitions.';}
                else{const q=await Providers.papiAccount();statusLine.textContent='Key test passed; provider quota '+q.requestCount+'/'+q.requestLimit+'.';}
            }));
        }else box.append(el('p','Public market and order-book reads require no key. Trading is not implemented. Availability is checked by your actual request; blocks are not bypassed.'));
    }
    const excluded=detail(settingsArea,'Providers not activated');
    excluded.append(el('p','Kalshi: its published API agreement limits use to the member’s own Kalshi trading. Betfair: live read-only access is disallowed and live activation is paid. PandaScore: free stats terms exclude betting use. Novig: open free data access not verified. SX Bet: US read-only data permission unresolved. Azuro: appropriate free feed terms/access unresolved. PredictionData.io: ongoing free plan not established.'));
    const tools=detail(settingsArea,'Diagnostics and backup');
    tools.append(button('🪲',()=>MyDebug.toggleView()),button('📋 Copy Logs to Clipboard',function(){return MyDebug.copy(this);}),button('Export settings + paper journal',()=>download('TBMA_Backup.json',JSON.stringify({schema:1,version:VERSION,settings,journal},null,2))));
    const file=labelInput(tools,'Import a non-secret TBMA backup','file');file.accept='.json,application/json';
    tools.append(button('Validate and merge backup',async()=>{
        if(!file.files?.[0] || file.files[0].size>2*1024*1024)throw new Error('Select a JSON backup under 2 MB');
        const data=JSON.parse(await file.files[0].text());if(data.schema!==1 || !Array.isArray(data.journal) || data.journal.length>1000)throw new Error('Unsupported backup');
        const imported=data.journal.map(validateJournalRow),merged=new Map(journal.map(r=>[r.id,r]));
        for(const r of imported)if(!merged.has(r.id))merged.set(r.id,{...r,origin:'imported-unverified'});
        if(merged.size>1000)throw new Error('Journal limit exceeded');
        const next={...settings};
        for(const k of Object.keys(DEFAULTS))if(k in (data.settings||{}) && typeof data.settings[k]===typeof DEFAULTS[k]){
            if(typeof DEFAULTS[k]==='number' && (!Number.isFinite(data.settings[k]) || data.settings[k]<0))throw new Error('Invalid setting');next[k]=data.settings[k];}
        if(next.maxAge<30 || next.maxAge>3600 || next.minSources<1 || next.minSources>20 || !Number.isInteger(next.minSources) || next.minEdge>1 || next.stake>1e9)throw new Error('Invalid imported thresholds');
        for(const p of ['toa','papi','poly']) {next[p+'Enabled']=false;if(next[p+'Budget']>PROVIDERS[p].limit || !Number.isInteger(next[p+'Budget']))throw new Error('Invalid imported budget');}
        const nextJournal=[...merged.values()];await Storage.write('journal',nextJournal);await Storage.write('settings',next);journal=nextJournal;settings=next;renderJournal();await buildSettings();statusLine.textContent='Backup merged. Providers disabled for review. Imported records are excluded from calibration.';
    }));
    tools.append(el('p','Backup excludes API keys, cached provider responses, DOM samples, and debug logs. Imported records are not treated as independently timestamped evidence.'));
    const supportHost=el('div');settingsArea.append(supportHost);
    if(support)support.destroy();support=new SupportModule({mount:supportHost,containerId:'tbma-support',styleId:'tbma-support-style'});
}
function renderReference(result) {
    clearTimeout(freshnessTimer);
    currentReference=result;sourceArea.replaceChildren();
    const times=result.provider==='poly'?result.books.map(b=>Date.parse(b.updatedAt)):result.sources.map(s=>Date.parse(s.updatedAt));
    const expiries=times.map(t=>t+settings.maxAge*1000-Date.now()).filter(t=>t>0);
    if(expiries.length)freshnessTimer=setTimeout(()=>{if(currentReference===result && root?.isConnected)renderReference(result);},Math.min(...expiries)+20);
    sourceArea.append(el('p','Reference freshness evaluated at '+new Date().toISOString()+'. Refresh is manual.'));
    sourceArea.append(el('h3','External market reference — not a verified Torn match'));
    sourceArea.append(el('p',result.ruleStatus,'tbma-notice'));
    if(result.provider==='poly') {
        sourceArea.append(el('strong',result.title));
        table(sourceArea,['Contract outcome','Reference midpoint','Bid / ask','Quote age','Depth (shares)'],result.outcomes.map((o,i)=>{
            const b=result.books[i],age=Math.max(0,Math.round((Date.now()-Date.parse(b.updatedAt))/1000));
            return [o,age>settings.maxAge?'STALE — no estimate':percent(result.probabilities[i]),`${b.bid} / ${b.ask}`,age+' seconds',`${b.bidSize} bid / ${b.askSize} ask`];
        }));
        sourceArea.append(el('p','Cumulative contract volume (provider units): '+String(result.volume??'Unavailable')+'. Volume is not the percentage of people backing an outcome.'));
        detail(sourceArea,'Resolution description').append(el('p',result.description));return;
    }
    const e=result.event;sourceArea.append(el('strong',e.participants.join(' vs ')+' · '+e.league));sourceArea.append(el('p','Start: '+e.start+' · External event ID: '+e.id));
    const outcomeSets=new Map();
    for(const s of result.sources){const key=[...s.outcomes].map(Core.name).sort().join('|');if(!outcomeSets.has(key))outcomeSets.set(key,[]);outcomeSets.get(key).push(s);}
    if(!outcomeSets.size)sourceArea.append(el('p','No usable complete market. See rejected sources.'));
    for(const group of outcomeSets.values()) {
        const outcomes=group[0].outcomes;
        const aligned=group.map(s=>({...s,probabilities:outcomes.map(o=>s.probabilities[s.outcomes.findIndex(n=>Core.name(n)===Core.name(o))])}));
        const c=Core.consensus(aligned,outcomes,Date.now(),settings.maxAge*1000);
        if(c.available){
            sourceArea.append(el('p',c.label+` · ${c.count} underlying sources · `+(c.renormalized?'Median vector renormalized.':'Probabilities sum to 100%.')));
            table(sourceArea,['Outcome','Reference probability','Source range width'],outcomes.map((o,i)=>[o,percent(c.probabilities[i]),(c.spread[i]*100).toFixed(1)+' percentage points']));
        }else sourceArea.append(el('p','No fresh estimate. Prices may be old, missing, or invalid.'));
        const breakdown=detail(sourceArea,'Source odds, freshness, and exclusions');
        table(breakdown,['Source','Decimal odds','Last quote/change time'],group.map(s=>[s.label,s.outcomes.map((o,i)=>o+': '+s.odds[i]).join(' · '),s.updatedAt]));
        for(const r of c.rejected)breakdown.append(el('p',r.source+': '+r.reason));
    }
    const rejected=detail(sourceArea,'Rejected sources');for(const r of result.rejected)rejected.append(el('p',r.source+': '+r.reason));
    sourceArea.append(el('p','Estimates use proportional margin removal. Two-way estimates may be conditional on a decisive result when a tie refunds. Bookmaker settlement rules are not verified equivalent; no Torn edge, favorite, or value badge is generated.'));
}
function buildProviderExplorer(parent) {
    const explorer=detail(parent,'External data — manual, quota-aware inspection');
    explorer.append(el('p','Inspect only an event you are viewing in Torn. No requests run on page load. These readers do not establish that a provider market matches Torn. Refresh uses the same cache for at least 60 seconds.'));
    const toa=detail(explorer,'The Odds API — events and head-to-head odds');
    const sport=selectInput(toa,'Sport / competition', [['','Load sports first']]);
    toa.append(button('Load sports (0 credits)',async()=>{const g=routeGeneration,s=await Providers.sports();if(g!==routeGeneration)return;sport.replaceChildren();for(const item of s){const o=el('option',item.group+' — '+item.title);o.value=item.key;sport.append(o);}}));
    const events=selectInput(toa,'External event',[['','Load events first']]);let loadedSport='';
    sport.addEventListener('change',()=>{events.replaceChildren();loadedSport='';});
    toa.append(button('Load events (0 credits)',async()=>{const g=routeGeneration,key=sport.value;if(!key)throw new Error('Select a sport');const list=await Providers.toaEvents(key);if(g!==routeGeneration||key!==sport.value)return;
        events.replaceChildren();loadedSport=key;for(const e of list){const o=el('option',e.participants.join(' vs ')+' — '+e.start);o.value=e.id;events.append(o);}statusLine.textContent=list.length+' external events; not matched to Torn.';
    }),button('Read selected odds (≤1 credit)',async()=>{if(!events.value||loadedSport!==sport.value)throw new Error('Load events for this sport');const g=routeGeneration,r=await Providers.toaOdds(sport.value,events.value);if(g===routeGeneration)renderReference(r);}));
    safeLink(toa,'Free key / provider plans','https://the-odds-api.com/');
    const papi=detail(explorer,'OddsPapi — tournament fixtures and full-time 1X2');
    const tournament=labelInput(papi,'Numeric tournament ID from OddsPapi documentation');
    const fixtures=selectInput(papi,'External fixture',[['','Load fixtures first']]);let loadedTournament='';
    tournament.addEventListener('input',()=>{fixtures.replaceChildren();loadedTournament='';});
    papi.append(button('Load fixtures (≤1 request)',async()=>{const g=routeGeneration,t=tournament.value.trim(),list=await Providers.papiFixtures(t);if(g!==routeGeneration||t!==tournament.value.trim())return;loadedTournament=t;fixtures.replaceChildren();for(const e of list){const o=el('option',e.participants.join(' vs ')+' — '+e.start);o.value=e.id;fixtures.append(o);}}),button('Read selected odds (≤2 requests)',async()=>{if(!fixtures.value||loadedTournament!==tournament.value.trim())throw new Error('Load fixtures first');const g=routeGeneration,r=await Providers.papiOdds(fixtures.value);if(g===routeGeneration)renderReference(r);}));
    safeLink(papi,'Free account','https://oddspapi.io/us/sign-up');papi.append(el('p','This adapter validates the provider’s market dictionary. Other esports and market formats remain unsupported until their schema and settlement rules are verified.'));
    const poly=detail(explorer,'Polymarket — binary market and two-sided books');
    const market=labelInput(poly,'Numeric market ID (not event ID or slug)');
    poly.append(button('Read market (≤3 public reads)',async()=>{const g=routeGeneration,r=await Providers.polyMarket(market.value.trim());if(g===routeGeneration)renderReference(r);}));
    safeLink(poly,'Public API documentation','https://docs.polymarket.com/api-reference/predictions/overview');
    sourceArea=el('div');explorer.append(sourceArea);
}
function buildCalculator(parent) {
    const calc=detail(parent,'Hypothetical payout calculator and paper journal');
    calc.append(el('p','Manual sandbox calculations only. Enter decimal odds that INCLUDE returned stake, or select another format. No values are read from your Torn bet slip. Expected value is available only for a simple win/lose model; ties, pushes, voids and partial settlements are not modeled in that estimate.'));
    const grid=el('div','','tbma-grid');calc.append(grid);
    const event=labelInput(grid,'Paper event label'),outcome=labelInput(grid,'Outcome label'),stake=labelInput(grid,'Hypothetical stake','number',settings.stake),odds=labelInput(grid,'Odds','text','');
    const format=selectInput(grid,'Odds format',[['decimal','Decimal'],['fractional','Fractional'],['american','American']]);
    const prob=labelInput(grid,'Optional probability % — your assumption','number','');prob.step='0.1';
    const start=labelInput(grid,'Scheduled start (UTC ISO, e.g. 2026-10-05T18:00:00Z)','text','');
    const result=el('div');calc.append(result);
    const values=()=>{const s=Core.number(stake.value),d=Core.decimal(odds.value,format.value),p=prob.value.trim()===''?null:Core.probability(Core.number(prob.value)/100);return{s,d,p};};
    calc.append(button('Calculate',()=>{const {s,d,p}=values(),x=Core.payouts(s,d,p);result.replaceChildren();
        table(result,['Calculation','Value'],[['Gross return if successful',money(x.gross)],['Net profit if successful',money(x.net)],['Loss if unsuccessful',money(x.loss)],['Break-even probability',percent(x.breakEven)],['Expected net profit (your assumption)',p===null?'No probability entered':money(x.expected)],['Expected ROI (your assumption)',p===null?'Unknown':percent(x.roi)],['Probability edge',p===null?'Unknown':(x.edge*100).toFixed(2)+' percentage points']]);
        result.append(el('p','Unrounded mathematical estimates; Torn rounding is not yet verified. This is not an automated recommendation.'));for(const warning of advisory(s,event.value))result.append(el('p','⚠ '+warning));
    }),button('Record paper bet (no real bet)',async()=>{
        const {s,d,p}=values();if(!event.value.trim()||!outcome.value.trim())throw new Error('Enter event and outcome labels');
        const startAt=Core.timestamp(start.value.trim());if(startAt<=Date.now())throw new Error('Record pre-event predictions only: start must be in the future');
        if(s<=0)throw new Error('Paper stake must exceed zero');if(journal.length>=1000)throw new Error('Export journal; the 1,000-record limit is reached');
        const row=validateJournalRow({id:crypto.randomUUID(),event:event.value.trim(),outcome:outcome.value.trim(),stake:s,odds:d,p,startAt,createdAt:Date.now(),settledAt:null,result:'pending',origin:'manual'});
        await Storage.write('journal',[...journal,row]);journal.push(row);renderJournal();statusLine.textContent='Paper bet recorded locally. Nothing was placed in Torn.';
    }));
    ledgerArea=el('div');calc.append(ledgerArea);renderJournal();
}
function validateJournalRow(r) {
    if(!r || typeof r!=='object' || !/^[a-zA-Z0-9-]{1,80}$/.test(r.id))throw new Error('Invalid journal ID');
    if(typeof r.event!=='string'||!r.event.trim()||r.event.length>200||typeof r.outcome!=='string'||!r.outcome.trim()||r.outcome.length>200)throw new Error('Invalid journal label');
    const stake=Core.number(r.stake),odds=Core.decimal(r.odds),p=r.p===null?null:Core.probability(r.p);
    Core.payouts(stake,odds,p);if(stake<=0)throw new Error('Invalid paper stake');
    if(!['pending','win','loss','void','push'].includes(r.result))throw new Error('Invalid result');
    const createdAt=Core.number(r.createdAt),startAt=Core.number(r.startAt),settledAt=r.result==='pending'?null:Core.number(r.settledAt);
    if(createdAt<946684800000||createdAt>Date.now()+30000||startAt<=createdAt||!Number.isFinite(new Date(startAt).getTime())||(settledAt!==null&&(settledAt<createdAt||settledAt>Date.now()+30000)))throw new Error('Invalid journal timestamps');
    return {id:r.id,event:r.event,outcome:r.outcome,stake,odds,p,startAt,createdAt,settledAt,result:r.result,origin:r.origin==='manual'?'manual':'imported-unverified'};
}
function advisory(stake,eventLabel) {
    const out=[],day=new Date().toISOString().slice(0,10),today=journal.filter(r=>new Date(r.createdAt).toISOString().slice(0,10)===day);
    const pending=journal.filter(r=>r.result==='pending');
    if(stake>settings.maxStake)out.push('Stake exceeds your advisory per-bet cap.');
    if(settings.bankroll>0 && stake>settings.bankroll)out.push('Stake exceeds your entered bankroll.');
    if(today.reduce((s,r)=>s+r.stake,0)+stake>settings.dailyStake)out.push('Recorded daily paper stakes would exceed the advisory limit.');
    if(pending.reduce((s,r)=>s+r.stake,0)+stake>settings.maxExposure)out.push('Recorded pending paper exposure would exceed the advisory limit.');
    const settledToday=journal.filter(r=>r.settledAt && new Date(r.settledAt).toISOString().slice(0,10)===day);
    if(settings.lossLimit>0 && Core.journalStats(settledToday).profit<=-settings.lossLimit)out.push('Recorded daily paper loss threshold reached.');
    if(eventLabel && pending.some(r=>Core.name(r.event)===Core.name(eventLabel)))out.push('Another pending paper bet has the same event label; exposure may be correlated.');
    return out;
}
function renderJournal(){if(!ledgerArea)return;ledgerArea.replaceChildren();const stats=Core.journalStats(journal);
    ledgerArea.append(el('h3','Local paper bets'),el('p',`Settled P/L ${money(stats.profit)} · Pending ${money(stats.pending)} · ROI ${stats.roi===null?'—':percent(stats.roi)} · Max drawdown ${money(stats.drawdown)}`));
    const scored=Core.journalStats(journal.filter(r=>r.origin==='manual'));ledgerArea.append(el('p',`Brier score ${scored.brier===null?'—':scored.brier.toFixed(4)} over ${scored.scored} manually recorded, binary settled predictions. Lower is better. Records use your device clock and are not tamper-proof.`));
    const today=new Date().toISOString().slice(0,10),dayPL=Core.journalStats(journal.filter(r=>r.settledAt&&new Date(r.settledAt).toISOString().slice(0,10)===today)).profit;
    if(settings.profitTarget>0)ledgerArea.append(el('p','Today’s paper settled P/L: '+money(dayPL)+' / aspirational target '+money(settings.profitTarget)+'. No stake adjustment.'));
    table(ledgerArea,['Event / outcome','Stake / locked odds','Result','Action'],journal.slice(-50).reverse().map(r=>{
        const action=el('div');if(r.result==='pending') {
            const select=el('select');for(const value of ['win','loss','void','push']){const o=el('option',value);o.value=value;select.append(o);}select.setAttribute('aria-label','Paper result for '+r.event);
            action.append(select,button('Settle paper entry',async()=>{if(Date.now()<r.startAt)throw new Error('Cannot settle before scheduled start');const next=journal.map(x=>x.id===r.id?{...x,result:select.value,settledAt:Date.now()}:x);await Storage.write('journal',next);journal=next;renderJournal();}));
        }
        return [r.event+' / '+r.outcome,money(r.stake)+' / '+r.odds,r.result,action];
    }));
}
function sanitizedElement(element) {
    if(!(element instanceof Element) || ['BODY','HTML'].includes(element.tagName) || root.contains(element)||element.contains(root))throw new Error('Select a single event card or bet row, not the whole page');
    if(element.querySelectorAll('*').length>500)throw new Error('Selection is too large; choose a smaller event card');
    const keep=new Set(['class','id','role','aria-label','type','name','colspan','rowspan']);
    const blocked=new Set(['SCRIPT','STYLE','LINK','META','IFRAME','OBJECT','EMBED','NOSCRIPT','SVG','IMG','VIDEO','AUDIO']);
    function copy(n) {
        if(n.nodeType===Node.TEXT_NODE) return document.createTextNode(Core.redact(n.textContent,[...sessionKeys.values()]).replace(/\b[A-Za-z0-9_-]{32,}\b/g,'[LONG_TOKEN]'));
        if(n.nodeType!==Node.ELEMENT_NODE || blocked.has(n.tagName))return null;
        const dest=document.createElement(n.tagName.toLowerCase());
        for(const attribute of n.attributes)if(keep.has(attribute.name))dest.setAttribute(attribute.name,Core.redact(attribute.value,[...sessionKeys.values()]).slice(0,500));
        if(['INPUT','TEXTAREA','SELECT'].includes(n.tagName)){dest.setAttribute('data-value-redacted','true');return dest;}
        for(const child of n.childNodes){const clean=copy(child);if(clean)dest.append(clean);}return dest;
    }
    const fragment=copy(element);if(!fragment)throw new Error('Choose the enclosing event card, not media');
    return fragment.outerHTML;
}
function buildEvidence(parent) {
    const box=detail(parent,'Needed to finish automatic Torn integration');
    box.append(el('p','Please provide one event-list card, its event-detail market, and one existing-bet row. The selector below intercepts the selection click, removes input values, URLs, scripts and most attributes, and shows a preview. Review text for personal data before sharing. Nothing is uploaded.'));
    let selected=null;const preview=el('textarea');preview.rows=10;preview.readOnly=true;preview.setAttribute('aria-label','Sanitized DOM sample preview');
    const refresh=()=>{if(!selected)return;preview.value=sanitizedElement(selected);};
    box.append(button('Select event card / bet row',()=>{
        if(cancelPick)cancelPick();statusLine.textContent='Click one event card or bet row. Selection will not activate its control. Press Escape to cancel.';
        const clean=()=>{window.removeEventListener('click',pick,true);window.removeEventListener('keydown',escape,true);cancelPick=null;};
        const pick=e=>{if(root.contains(e.target))return;e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();clean();selected=e.target;try{refresh();statusLine.textContent='Selected. Use Parent element until the preview contains just the event/market, then review and save.';}catch(err){showError(err);}};
        const escape=e=>{if(e.key==='Escape'){clean();statusLine.textContent='Selection cancelled.';}};
        window.addEventListener('click',pick,true);window.addEventListener('keydown',escape,true);cancelPick=clean;
    }),button('Parent element',()=>{if(!selected?.parentElement)throw new Error('Select an element first');const next=selected.parentElement;const html=sanitizedElement(next);selected=next;preview.value=html;}),preview,button('Save reviewed sample',()=>{
        if(!preview.value)throw new Error('Select an event card first');return download('TBMA_DOM_sample.txt','TBMA sanitized DOM sample\nRoute: '+location.pathname+'?sid=bookie'+location.hash+'\nCaptured: '+new Date().toISOString()+'\n\n'+preview.value,'text/plain');
    }));
    box.append(el('p','Also include a screenshot showing the same odds and a hypothetical stake/potential-profit display. Do not place a bet for testing. Do not send API keys, cookies, account credentials, or a full network/HAR export.'));
}
function styles() {
    if(document.getElementById('tbma-style'))return;const s=el('style');s.id='tbma-style';s.textContent=`
#tbma-root{box-sizing:border-box;max-width:1100px;margin:12px auto;padding:12px;background:#17202c;color:#eaf0f8;border:1px solid #52647c;border-radius:8px;font:14px/1.5 system-ui,sans-serif;position:relative;z-index:100}
#tbma-root *{box-sizing:border-box}#tbma-root [hidden]{display:none!important}#tbma-root header{display:flex;align-items:center;gap:8px;flex-wrap:wrap}#tbma-root header strong{flex:1}#tbma-root button,#tbma-root select,#tbma-root input{font:inherit;border:1px solid #798ca4;border-radius:5px;min-height:38px;padding:6px 9px;background:#25364b;color:#fff;max-width:100%}#tbma-root button{cursor:pointer;margin:3px}#tbma-root button:disabled{opacity:.5;cursor:default}#tbma-root :focus-visible{outline:3px solid #7cbfff;outline-offset:2px}#tbma-root input[type=checkbox]{min-height:22px;width:22px}#tbma-root h3{font-size:16px;margin:12px 0 6px;color:#fff}#tbma-root p{margin:8px 0}#tbma-root a{color:#9bcdff}#tbma-root details{border-top:1px solid #40516a;padding:9px 0;margin-top:6px}#tbma-root summary{cursor:pointer;padding:7px 0;font-weight:600}#tbma-root table{width:100%;border-collapse:collapse;font-size:13px}#tbma-root td,#tbma-root th{text-align:left;border-bottom:1px solid #40516a;padding:8px;vertical-align:top;overflow-wrap:anywhere}#tbma-root .tbma-scroll{overflow-x:auto}#tbma-root .tbma-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}#tbma-root .tbma-field{display:flex;flex-direction:column;gap:4px;margin:7px 0}#tbma-root textarea{width:100%;background:#0f1722;color:#dce8f8;font:12px/1.4 monospace;padding:8px}#tbma-root .tbma-notice{border-left:3px solid #e9b85a;padding:8px;background:#283044}#tbma-root [data-tbma-health]{display:flex;flex-direction:column;font-size:12px;color:#b9c9de}#tbma-root #tbma-support{position:static!important;inset:auto!important;z-index:auto!important;max-width:360px;margin-top:16px}#tbma-root #tbma-support .tw-torn-tip{color:#112000!important}
@media(max-width:500px){#tbma-root{margin:6px;padding:9px}#tbma-root .tbma-grid{grid-template-columns:1fr}#tbma-root table{font-size:12px}}
`;document.head.append(s);
}
async function mount() {
    if(!isBookie())return;
    if(root?.isConnected)return;
    if(root){document.body.prepend(root);return;}
    styles();root=el('section');root.id='tbma-root';root.setAttribute('aria-label',APP);
    const head=el('header'),title=el('strong',APP+' · '+VERSION+' verification release');
    content=el('div');content.id='tbma-content';content.hidden=settings.collapsed;
    const collapse=button(settings.collapsed?'Expand':'Collapse',async()=>{settings.collapsed=!settings.collapsed;content.hidden=settings.collapsed;collapse.textContent=settings.collapsed?'Expand':'Collapse';collapse.setAttribute('aria-expanded',String(!settings.collapsed));await Storage.write('settings',settings);});collapse.setAttribute('aria-controls',content.id);collapse.setAttribute('aria-expanded',String(!settings.collapsed));
    settingsArea=el('div');settingsArea.hidden=true;settingsArea.id='tbma-settings';
    const gear=button('⚙ Settings',()=>{settingsArea.hidden=!settingsArea.hidden;gear.setAttribute('aria-expanded',String(!settingsArea.hidden));});gear.setAttribute('aria-controls',settingsArea.id);gear.setAttribute('aria-expanded','false');
    head.append(title,collapse,gear);statusLine=el('p','Automatic Torn extraction: awaiting authenticated page samples. No bets or estimates have been inferred.','tbma-notice');statusLine.setAttribute('role','status');
    const health=el('div');health.setAttribute('data-tbma-health','');
    root.append(head,statusLine,health,content,settingsArea);document.body.prepend(root);
    content.append(el('p','This verification build supplies real API readers, an independent calculator, a paper journal, and a DOM sample collector. Automatic event matching, inline Torn annotations, and real-bet accounting are not active.'));
    buildEvidence(content);buildProviderExplorer(content);buildCalculator(content);await buildSettings();renderHealth();
    log('mounted',{version:VERSION,mode:'verification',automaticTornIntegration:false});
}
async function start() {
    const saved=await Storage.read('settings',{});
    for(const k of Object.keys(DEFAULTS))if(typeof saved[k]===typeof DEFAULTS[k])settings[k]=saved[k];
    // Discard corrupted/untrusted setting ranges; imports validate separately.
    for(const k of Object.keys(DEFAULTS))if(typeof DEFAULTS[k]==='number' && (!Number.isFinite(settings[k]) || settings[k]<0 || settings[k]>1e9))settings[k]=DEFAULTS[k];
    settings.maxAge=Math.min(3600,Math.max(30,settings.maxAge));settings.minEdge=Math.min(1,settings.minEdge);settings.minSources=Math.min(20,Math.max(1,Math.round(settings.minSources)));
    for(const p of ['toa','papi','poly'])settings[p+'Budget']=Math.min(PROVIDERS[p].limit,Math.floor(settings[p+'Budget']));
    const stored=await Storage.read('journal',[]);if(Array.isArray(stored))for(const r of stored.slice(0,1000)){try{journal.push(validateJournalRow(r));}catch(_){log('journal','Skipped malformed saved record','WARN');}}
    await mount();
    const navigate=()=>{routeGeneration++;cancelPick?.();clearTimeout(freshnessTimer);currentReference=null;if(sourceArea)sourceArea.replaceChildren(el('p','Route changed. Select and refresh the relevant external event.'));if(!isBookie()){root?.remove();return;}void mount().catch(showError);};
    window.addEventListener('hashchange',navigate,{signal:listeners.signal});window.addEventListener('popstate',navigate,{signal:listeners.signal});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){routeGeneration++;clearTimeout(freshnessTimer);currentReference=null;if(sourceArea)sourceArea.replaceChildren(el('p','Page hidden; refresh references after returning.'));}},{signal:listeners.signal});
    // Observe direct body children only, to reattach our own panel after a layout replacement.
    lifeObserver=new MutationObserver(()=>{if(isBookie() && root && !root.isConnected)document.body.prepend(root);});
    lifeObserver.observe(document.body,{childList:true});
    window.addEventListener('pagehide',()=>{routeGeneration++;cancelPick?.();clearTimeout(freshnessTimer);lifeObserver?.disconnect();},{signal:listeners.signal});
    window.addEventListener('pageshow',()=>{if(isBookie())lifeObserver?.observe(document.body,{childList:true});},{signal:listeners.signal});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>void start().catch(showError),{once:true});
else void start().catch(showError);
