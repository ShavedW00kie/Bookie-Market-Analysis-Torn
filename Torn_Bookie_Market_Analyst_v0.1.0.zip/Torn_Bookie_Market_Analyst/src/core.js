/* Pure analysis functions. No DOM, credentials, or network. BSD-3-Clause. */
const Core = (() => {
    const fail = message => { throw new Error(message); };
    const number = (value, name = 'number') => {
        if (value === null || value === undefined || typeof value === 'boolean' || String(value).trim() === '') fail(`Missing ${name}`);
        const n = Number(value);
        if (!Number.isFinite(n)) fail(`Invalid ${name}`);
        return n;
    };
    const decimal = (value, format = 'decimal') => {
        let d;
        if (format === 'fractional') {
            const match = String(value).trim().match(/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/);
            if (!match || Number(match[2]) <= 0) fail('Invalid fractional odds');
            d = 1 + Number(match[1]) / Number(match[2]);
        } else if (format === 'american') {
            const a = number(value, 'American odds');
            if (Math.abs(a) < 100) fail('American odds must be at least +100 or at most -100');
            d = a > 0 ? 1 + a / 100 : 1 + 100 / -a;
        } else if (format === 'decimal') d = number(value, 'decimal odds');
        else fail('Unsupported odds format');
        if (d <= 1 || d > 1000000) fail('Decimal odds must exceed 1 and be at most 1,000,000');
        return d;
    };
    const probability = value => {
        const p = number(value, 'probability');
        if (p < 0 || p > 1) fail('Probability outside [0,1]');
        return p;
    };
    const normalize = values => {
        if (!Array.isArray(values) || values.length < 2) fail('At least two exhaustive outcomes required');
        const v = values.map(probability), sum = v.reduce((a, b) => a + b, 0);
        if (sum <= 0) fail('Zero probability mass');
        return v.map(x => x / sum);
    };
    const devig = odds => normalize(odds.map(o => 1 / decimal(o)));
    const payouts = (stake, odds, p, settlement = 'win-lose') => {
        const s = number(stake, 'stake'), d = decimal(odds);
        if (s < 0 || s > 1e9) fail('Stake must be from 0 through 1,000,000,000');
        if (settlement !== 'win-lose') fail('Expected value unavailable for this settlement model');
        const result = {gross: s * d, net: s * (d - 1), loss: s, breakEven: 1 / d};
        if (p !== null && p !== undefined) {
            p = probability(p);
            Object.assign(result, {expected: s * (p * d - 1), roi: p * d - 1, edge: p - 1 / d});
        }
        return result;
    };
    const settledNet = (stake, odds, result) => {
        const x = payouts(stake, odds, null);
        if (result === 'win') return x.net;
        if (result === 'loss') return -x.loss;
        if (result === 'void' || result === 'push') return 0;
        fail('Unsupported settlement; do not approximate partial wins');
    };
    const name = value => String(value ?? '').normalize('NFKC').toLocaleLowerCase('en-US').replace(/\s+/g, ' ').trim();
    const timestamp = value => {
        if (typeof value !== 'string' || !/(?:Z|[+-]\d\d:\d\d)$/.test(value)) fail('Explicit ISO time zone required');
        const n = Date.parse(value);
        if (!Number.isFinite(n)) fail('Invalid timestamp');
        return n;
    };
    const median = array => {
        if (!array.length) fail('No observations');
        const a = [...array].sort((x, y) => x - y), mid = Math.floor(a.length / 2);
        return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
    };
    const sourceId = value => name(value).replace(/[^a-z0-9]/g, '');
    const compareEvents = (a, b, aliases = {}) => {
        // Aliases are sport-scoped exact name pairs, never fuzzy substring matches.
        const canon = v => name(aliases[`${name(a.sport)}:${name(v)}`] || v);
        const bad = reason => ({ok: false, score: 0, reason});
        if (!a || !b) return bad('Missing event');
        for (const field of ['sport','league','marketType','period','scope','settlementSignature']) {
            if (!name(a[field]) || !name(b[field])) return bad(`Unknown ${field}`);
            if (name(a[field]) !== name(b[field])) return bad(`Different ${field}`);
        }
        if (a.rulesVerified !== true || b.rulesVerified !== true) return bad('Settlement rules not independently verified');
        if (a.marketType !== 'winner' || !['match','series'].includes(a.scope)) return bad('Unsupported market structure');
        if (a.status !== 'prematch' || b.status !== 'prematch') return bad('Live, postponed, or closed event');
        if (a.scope === 'series' && (!Number.isInteger(a.bestOf) || a.bestOf !== b.bestOf)) return bad('Unknown or different best-of format');
        if (!Array.isArray(a.participants) || !Array.isArray(b.participants)) return bad('Missing participants');
        const ap = a.participants.map(canon).sort(), bp = b.participants.map(canon).sort();
        if (ap.length !== 2 || bp.length !== 2 || new Set(ap).size !== 2 || new Set(bp).size !== 2 || ap.join('\u0000') !== bp.join('\u0000')) return bad('Participant mismatch');
        let delta;
        try { delta = Math.abs(timestamp(a.start) - timestamp(b.start)); } catch (_) { return bad('Unknown start time'); }
        if (delta > 5 * 60000) return bad('Start differs by more than five minutes; rescheduling requires review');
        if (a.exhaustive !== true || b.exhaustive !== true) return bad('Incomplete outcomes');
        const ao = (a.outcomes || []).map(canon), bo = (b.outcomes || []).map(canon);
        if (ao.length < 2 || ao.length > 3 || new Set(ao).size !== ao.length || new Set(bo).size !== bo.length || [...ao].sort().join('\u0000') !== [...bo].sort().join('\u0000')) return bad('Outcome mismatch');
        return {ok: true, score: delta === 0 ? 100 : 95, reason: 'Exact identity and verified rule match; score is not a win probability', order: ao.map(x => bo.indexOf(x))};
    };
    const chooseEvent = (target, candidates, aliases = {}) => {
        const matches = candidates.map(event => ({event, match: compareEvents(target, event, aliases)})).filter(x => x.match.ok);
        const unique = new Map(matches.map(x => [x.event.id, x]));
        if (unique.size !== 1) return {ok:false, reason: unique.size ? 'Ambiguous matching fixtures' : 'No verified compatible fixture'};
        return [...unique.values()][0];
    };
    const consensus = (sources, outcomes, now, maxAgeMs = 300000) => {
        const accepted = new Map(), rejected = [];
        for (const s of sources) {
            try {
                if (!s.compatible || !s.exhaustive) fail('Rules/outcome completeness unverified');
                if (!Array.isArray(s.probabilities) || s.probabilities.length !== outcomes.length) fail('Missing outcomes');
                const t = timestamp(s.updatedAt);
                if (t > now + 30000 || now - t > maxAgeMs) fail('Stale or future source timestamp');
                if (!s.underlyingSource) fail('Unknown underlying source');
                const values = s.probabilities.map(probability);
                if (Math.abs(values.reduce((a,b)=>a+b,0)-1) > 1e-6) fail('Source probabilities do not sum to one');
                const id = sourceId(s.underlyingSource);
                if (!id) fail('Unknown source');
                const existing = accepted.get(id);
                if (!existing || timestamp(existing.updatedAt) < t) accepted.set(id, {...s, probabilities: values});
            } catch (e) { rejected.push({source:s.underlyingSource || 'unknown', reason:e.message}); }
        }
        const data = [...accepted.values()];
        if (!data.length) return {available:false, rejected};
        const raw = outcomes.map((_,i) => median(data.map(s=>s.probabilities[i])));
        const probabilities = normalize(raw);
        const spread = outcomes.map((_,i) => Math.max(...data.map(s=>s.probabilities[i]))-Math.min(...data.map(s=>s.probabilities[i])));
        return {available:true, probabilities, spread, count:data.length, sources:data, rejected,
            renormalized:Math.abs(raw.reduce((a,b)=>a+b,0)-1)>1e-9,
            label:data.length===1?'Single-source estimate':'Median consensus'};
    };
    const midpoint = (bid, ask, bidSize, askSize, maxSpread = 0.1) => {
        bid=probability(bid); ask=probability(ask);
        if (bid <= 0 || ask >= 1 || ask < bid) fail('Empty or crossed order book');
        if (number(bidSize)<=0 || number(askSize)<=0) fail('No two-sided liquidity');
        if (ask-bid>maxSpread) fail('Wide spread');
        return {p:(bid+ask)/2, spread:ask-bid};
    };
    const redact = (value, secrets = []) => {
        let text = typeof value === 'string' ? value : JSON.stringify(value, (key, item) => /api.?key|token|authorization|password|cookie|secret|signature|email/i.test(key) ? '[REDACTED]' : item);
        text = String(text ?? '');
        for (const secret of secrets.filter(Boolean).sort((a,b)=>b.length-a.length)) {
            text = text.split(secret).join('[REDACTED]').split(encodeURIComponent(secret)).join('[REDACTED]');
        }
        return text.replace(/([?&](?:api[_-]?key|key|token|signature|auth)[^=\s]*=)[^&\s"<>]+/gi,'$1[REDACTED]')
            .replace(/Bearer\s+[^\s"<>]+/gi,'Bearer [REDACTED]')
            .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[EMAIL]');
    };
    const journalStats = rows => {
        const settled = rows.filter(r=>r.result !== 'pending').sort((a,b)=>a.settledAt-b.settledAt);
        let profit=0, turnover=0, peak=0, drawdown=0, brier=0, scored=0;
        for (const r of settled) {
            profit+=settledNet(r.stake,r.odds,r.result);
            if (r.result!=='void' && r.result!=='push') turnover+=r.stake;
            peak=Math.max(peak,profit); drawdown=Math.max(drawdown,peak-profit);
            if (r.p !== null && ['win','loss'].includes(r.result)) { brier+=(r.p-(r.result==='win'?1:0))**2; scored++; }
        }
        return {profit,turnover,roi:turnover?profit/turnover:null,drawdown,brier:scored?brier/scored:null,scored,pending:rows.filter(r=>r.result==='pending').reduce((a,b)=>a+b.stake,0)};
    };
    return {number, decimal, probability, normalize, devig, payouts, settledNet, name, timestamp, median, sourceId, compareEvents, chooseEvent, consensus, midpoint, redact, journalStats};
})();
