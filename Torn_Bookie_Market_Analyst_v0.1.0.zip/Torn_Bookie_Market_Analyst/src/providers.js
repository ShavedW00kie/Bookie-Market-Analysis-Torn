/* Read-only provider adapters. Reference estimates never authorize a Torn match. */
const Providers = (()=>{
    const str=(v,label)=>{if(typeof v!=='string' || !v.trim() || v.length>1000)throw new Error('Invalid '+label);return v;};
    const array=(v,label)=>{if(!Array.isArray(v) || v.length>10000)throw new Error('Invalid '+label);return v;};
    const id=(v)=>{v=String(v);if(!/^[a-zA-Z0-9_-]{1,128}$/.test(v))throw new Error('Invalid provider identifier');return v;};
    const date=v=>new Date(Core.timestamp(v)).toISOString();
    function toaEvent(e) {
        return {id:id(e.id),sportKey:id(e.sport_key),league:str(e.sport_title||e.sport_key,'league'),start:date(e.commence_time),participants:[str(e.home_team,'home team'),str(e.away_team,'away team')]};
    }
    function toaParse(data) {
        const event=toaEvent(data),sources=[],rejected=[];
        for(const book of array(data.bookmakers,'bookmakers')) {
            try {
                const key=id(book.key),markets=array(book.markets,'markets');
                const selected=markets.filter(m=>m.key==='h2h');
                if(selected.length!==1)throw new Error('Missing or ambiguous head-to-head market');
                const m=selected[0],outcomes=array(m.outcomes,'outcomes');
                const names=outcomes.map(o=>str(o.name,'outcome'));
                if(names.length<2 || names.length>3 || new Set(names.map(Core.name)).size!==names.length)throw new Error('Invalid outcome set');
                const canonical=[...event.participants,...(names.some(n=>Core.name(n)==='draw')?['Draw']:[])];
                if(canonical.length!==names.length || canonical.some(n=>!names.some(x=>Core.name(x)===Core.name(n))))throw new Error('Incomplete or unexpected outcomes');
                const odds=canonical.map(n=>Core.decimal(outcomes.find(o=>Core.name(o.name)===Core.name(n)).price));
                // Exchange h2h prices need bid/ask depth; do not de-vig them as fixed-odds books.
                if(/betfair|exchange|kalshi|polymarket|novig|sxbet/i.test(key))throw new Error('Exchange quote excluded: missing two-sided depth and rule validation');
                sources.push({underlyingSource:key,label:book.title||key,outcomes:canonical,odds,probabilities:Core.devig(odds),updatedAt:date(m.last_update||book.last_update),exhaustive:true,compatible:true});
            }catch(e){rejected.push({source:book.key||'unknown',reason:e.message});}
        }
        return {provider:'toa',event,sources,rejected,ruleStatus:'Provider h2h reference only. Torn settlement compatibility unverified.'};
    }
    function papiEvent(e) {
        return {id:id(e.fixtureId),sportKey:String(Core.number(e.sportId)),league:str(e.tournamentName,'tournament'),start:date(e.startTime),participants:[str(e.participant1Name,'participant 1'),str(e.participant2Name,'participant 2')],statusId:Core.number(e.statusId)};
    }
    function papiParse(data,dictionary) {
        const event=papiEvent(data),sources=[],rejected=[];
        if(event.statusId!==0)throw new Error('Only pre-match fixtures are supported');
        if(!data.bookmakerOdds || typeof data.bookmakerOdds!=='object')throw new Error('Missing bookmaker odds');
        const markets=array(dictionary,'market dictionary').filter(m=>m.sportId===data.sportId && m.marketType==='1x2' && m.period==='fulltime' && m.playerProp===false && m.marketLength===3);
        if(markets.length!==1)throw new Error('Only one unambiguous full-time 1X2 market is supported in this release');
        const def=markets[0],labels={'1':event.participants[0],'X':'Draw','2':event.participants[1]};
        if(!Array.isArray(def.outcomes) || def.outcomes.length!==3 || new Set(def.outcomes.map(o=>o.outcomeName)).size!==3 || def.outcomes.some(o=>!labels[o.outcomeName]))throw new Error('Unsupported outcome dictionary');
        for(const [key,book] of Object.entries(data.bookmakerOdds)) {
            try {
                if(/exchange|betfair|kalshi|polymarket|novig|sxbet/i.test(key))throw new Error('Exchange prices excluded');
                if(book.bookmakerIsActive!==true || book.suspended===true)throw new Error('Bookmaker inactive/suspended');
                const market=book.markets?.[String(def.marketId)];
                if(!market || market.marketActive===false)throw new Error('Full-time market unavailable');
                const odds=[],times=[],names=[];
                for(const out of def.outcomes) {
                    const players=market.outcomes?.[String(out.outcomeId)]?.players;
                    if(!players || Object.keys(players).length!==1 || !players['0'])throw new Error('Ambiguous/player-prop outcome');
                    const price=players['0'];
                    if(price.active!==true)throw new Error('Inactive outcome');
                    odds.push(Core.decimal(price.price));times.push(Core.timestamp(price.changedAt));names.push(labels[out.outcomeName]);
                }
                sources.push({underlyingSource:key,label:key,outcomes:names,odds,probabilities:Core.devig(odds),updatedAt:new Date(Math.min(...times)).toISOString(),exhaustive:true,compatible:true});
            }catch(e){rejected.push({source:key,reason:e.message});}
        }
        return {provider:'papi',event,sources,rejected,ruleStatus:'Full-time 1X2 reference only. Changed-at time is conservatively used; unchanged prices may appear stale. Torn cancellation rules unverified.'};
    }
    function polyBook(book,token) {
        if(String(book.asset_id)!==String(token))throw new Error('Orderbook token mismatch');
        const bids=array(book.bids,'bids').map(o=>({price:Core.probability(o.price),size:Core.number(o.size)})).filter(o=>o.size>0);
        const asks=array(book.asks,'asks').map(o=>({price:Core.probability(o.price),size:Core.number(o.size)})).filter(o=>o.size>0);
        const bid=bids.sort((a,b)=>b.price-a.price)[0],ask=asks.sort((a,b)=>a.price-b.price)[0];
        if(!bid || !ask)throw new Error('No two-sided orderbook');
        const middle=Core.midpoint(bid.price,ask.price,bid.size,ask.size);
        const n=Core.number(book.timestamp,'book timestamp');
        const time=n<1e11?n*1000:n;
        if(time<946684800000 || time>Date.now()+30000)throw new Error('Unexpected orderbook timestamp');
        return {...middle,bid:bid.price,ask:ask.price,bidSize:bid.size,askSize:ask.size,updatedAt:new Date(time).toISOString()};
    }
    return {
        toaParse,papiParse,polyBook,
        async sports() {
            return array(await api('toa','/v4/sports',{},0,86400000),'sports').filter(s=>s.active===true && s.has_outrights===false)
                .map(s=>({key:id(s.key),title:str(s.title,'title'),group:str(s.group,'group')}));
        },
        async toaEvents(sport) {
            return array(await api('toa','/v4/sports/'+id(sport)+'/events',{},0,300000),'events').map(toaEvent);
        },
        async toaOdds(sport,event) {
            return toaParse(await api('toa','/v4/sports/'+id(sport)+'/events/'+id(event)+'/odds',{markets:'h2h',regions:'us',oddsFormat:'decimal',dateFormat:'iso'},1,60000));
        },
        async papiAccount() {return api('papi','/v4/account',{},0,0);},
        async papiFixtures(tournament) {
            if(!/^\d+$/.test(tournament))throw new Error('Numeric tournament ID required');
            return array(await api('papi','/v4/fixtures',{tournamentId:tournament,statusId:0,hasOdds:true,language:'en'},1,300000),'fixtures').map(papiEvent);
        },
        async papiOdds(event) {
            const dict=await api('papi','/v4/markets',{language:'en'},1,7*86400000);
            const data=await api('papi','/v4/odds',{fixtureId:id(event),oddsFormat:'decimal',language:'en',verbosity:3},1,60000);
            return papiParse(data,dict);
        },
        async polyMarket(marketId) {
            if(!/^\d{1,30}$/.test(marketId))throw new Error('Enter a numeric Polymarket market ID, not an event slug');
            const data=await api('poly','/markets/'+marketId,{},1,60000);
            if(String(data.id)!==marketId || data.active!==true || data.closed!==false || data.enableOrderBook!==true)throw new Error('Market is inactive, closed, or has no order book');
            const parse=v=>typeof v==='string'?JSON.parse(v):v;
            const outcomes=array(parse(data.outcomes),'outcomes'),tokens=array(parse(data.clobTokenIds),'token IDs');
            if(outcomes.length!==2 || tokens.length!==2 || new Set(tokens).size!==2)throw new Error('Only complete two-outcome contracts supported');
            const books=[];
            for(const token of tokens) {
                if(!/^\d{1,100}$/.test(String(token)))throw new Error('Invalid token ID');
                const book=await api('poly','/book',{token_id:String(token)},1,60000);
                if(book.market!==data.conditionId)throw new Error('Orderbook condition mismatch');
                books.push(polyBook(book,token));
            }
            if(Math.abs(books[0].p+books[1].p-1)>0.05)throw new Error('Inconsistent outcome books');
            return {provider:'poly',title:str(data.question,'question'),description:String(data.description||''),outcomes:outcomes.map(x=>str(x,'outcome')),books,
                probabilities:Core.normalize(books.map(b=>b.p)),volume:data.volumeNum??data.volume??null,
                ruleStatus:'Standalone binary contract. No mapping of No to the opposing team; no Torn match has been verified.'};
        }
    };
})();
